<?php $__env->startSection('content'); ?>
<style>
    .w-5{
        font-size: 10px !imporntant;
        width: 20px; !important;
        vertical-align: middle;
    }
    nav .flex{
        display: none !important;
    }
</style>
<!-- Section Area - Content Central -->
<section class="content-info">

    <div class="container paddings-mini">
       <div class="row">

            <!-- Sidebars -->
            <aside class="col-lg-3">

                <div>
                    <h4>Хайлтын хэсэг</h4>
                    <form class="search" action="<?php echo e(url('/news/search')); ?>" method="get">
                        <div class="input-group">
                            <input class="form-control" placeholder="Search..." name="searchkey"  type="text" required="required">
                            <span class="input-group-btn">
                                <button class="btn btn-primary" type="submit">Хайх!</button>
                            </span>
                        </div>
                    </form>
                </div>

                <!-- Widget Categories-->
                <div class="panel-box">
                    <div class="titles no-margin">
                        <h4>Категори</h4>
                    </div>
                    <div class="info-panel">
                        <ul class="list">
                            <?php $__currentLoopData = $ArticleCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="fa fa-check"></i><a href="<?php echo e(url('/news/category/'.$category->id.'/'.$category->category)); ?>"><?php echo e($category->category); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <!-- End Widget Categories-->

            </aside>
            <!-- End Sidebars -->


            <div class="col-lg-9">
                <!-- Content Text-->

                    <div class="home-slider">
                      <div class="col-lg-8 col-xl-8">
                        <div class="card-wrapper">
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key == 0): ?>
                                    <article class="card" role="article">
                                        <a href="<?php echo e(url('/news/'.$article->id.'/'.$article->slug)); ?>">
                                        <div class="card-text">
                                            <div class="card-meta"><i class="fa fa-calendar"></i> <?php echo e($article->updated_at->diffForHumans()); ?></i></div>
                                            <h2 class="card-title">
                                                <?php echo e(Str::limit($article->title, 60)); ?>

                                            </h2>
                                        </div>
                                        <img class="card-image" src="<?php echo e(url($article->image)); ?>" alt="<?php echo e($article->title); ?>"/>
                                        </a>
                                    </article>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      </div>
                      <div class="col-lg-4 col-xl-4">
                        <div class="card-wrapper">
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key == 1): ?>
                                    <article class="card" role="article">
                                        <a href="<?php echo e(url('/news/'.$article1->id.'/'.$article1->slug)); ?>">
                                        <div class="card-text">
                                            <div class="card-meta"><i class="fa fa-calendar"></i> <?php echo e($article1->updated_at->diffForHumans()); ?></i></div>
                                            <h2 class="card-title">
                                                <?php echo e(Str::limit($article1->title, 60)); ?>

                                            </h2>
                                        </div>
                                        <img class="card-image" src="<?php echo e(url($article1->image)); ?>" alt="<?php echo e($article1->title); ?>"/>
                                        </a>
                                    </article>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      </div>
                    </div>
                    <div class="home-slider mb-4">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($key > 1): ?>
                                <div class="col-lg-4 col-xl-4">
                                    <div class="card-wrapper">
                                    <article class="card" role="article">
                                        <a href="<?php echo e(url('/news/'.$article2->id.'/'.$article2->slug)); ?>">
                                        <div class="card-text">
                                            <div class="card-meta"><i class="fa fa-calendar"></i> <?php echo e($article2->updated_at->diffForHumans()); ?></i></div>
                                            <h2 class="card-title">
                                                <?php echo e(Str::limit($article2->title, 60)); ?>

                                            </h2>
                                        </div>
                                        <img class="card-image" src="<?php echo e(url($article2->image)); ?>" alt="<?php echo e($article2->title); ?>"/>
                                        </a>
                                    </article>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="home-slider mb-4">
                        <?php echo e($articles->links()); ?>

                    </div>
                <!-- End Content Text-->
            </div>
       </div>
    </div>
</section>
<!-- End Section Area -  Content Central -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Tsenguun\voly\volleyball.mn\resources\views/newslist.blade.php ENDPATH**/ ?>