<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title><?php echo e(config('app.name', 'Монголын волейболын залуучуудын холбоо - Mongolian volleyball youth association')); ?></title>
    <?php $alt = 'Монголын волейболын залуучуудын холбоо - Mongolian volleyball youth association'; ?>
    <link href="<?php echo e(url('/assets/assets/css/main.css')); ?>" rel="stylesheet" media="screen" />


    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>

    <?php echo $__env->yieldContent('css'); ?>
  </head>

  <body>

    <!-- layout-->
    <div id="layout">
      <!-- Header-->
      <header class="mobile-only-header">
        <!-- End headerbox-->
        <div class="headerbox">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <!-- Logo-->
                    <div class="col">
                      <div class="logo">
                          <a href="<?php echo e(url('/')); ?>" title="Return Home">
                                <img src="<?php echo e(url('/assets/images/logo.png')); ?>" alt="<?php echo e($alt); ?>" class="logo_img" width="60">
                            </a>
                      </div>
                    </div>
                    <!-- End Logo-->
                    <button class="watch-button" style="margin-right: 1.5em">Live<span class="live-icon"></span></button>

                        <!-- Call Nav Menu-->
                        <a class="mobile-nav" href="#mobile-nav"><i class="fa fa-bars"></i></a>
                        <!-- End Call Nav Menu-->
                    <!-- End Adds Header-->
                </div>
            </div>
        </div>
        <!-- End headerbox-->
      </header>
      <!-- End Header-->
      <!-- mainmenu-->
      <nav class="mainmenu">
        <div class="container">
          <div class="menu-icon">
            <img src="<?php echo e(url('/assets/images/logo.png')); ?>" alt="<?php echo e($alt); ?>" />
          </div>
          <!-- Menu-->
          <ul class="sf-menu" id="menu">
            <li class="float-right">
              <i class="fa fa-search color-white" style="cursor: pointer"></i>
            </li>

            <li class="float-right">
              <button class="watch-button">Live<span class="live-icon"></span></button>
            </li>

            <li class="<?php if($page == 'newslist'): ?>current active <?php endif; ?>">
              <a href="<?php echo e(url('/news/list')); ?>">Мэдээ</a>
            </li>

            <li class="<?php if($page == 'home'): ?>current active <?php endif; ?>">
              <a href="<?php echo e(url('/')); ?>">Нүүр хуудас</a>
            </li>

          </ul>
          <!-- End Menu-->
          <!-- Color Red -->
        </div>
      </nav>
      <!-- End mainmenu-->
      <div id="mobile-nav">
        <!-- Menu-->
        <ul>
            <li>
              <a href="<?php echo e(url('/')); ?>">Нүүр</a>
            </li>
            <li>
              <a href="<?php echo e(url('/news/list')); ?>">Мэдээ</a>
            </li>
          </ul>
        <!-- End Menu-->
      </div>
      <!-- End -->
      <?php echo $__env->yieldContent('content'); ?>






      <!-- footer-->
      <footer id="footer" class="footer-3">
        <!-- Footer Top-->
        <div class="top-footer">

            <!-- Logo Footer-->
           <div class="col-lg-12">
            <div class="logo-footer">
              <img src="<?php echo e(url('/assets/images/logo.png')); ?>" alt="<?php echo e($alt); ?>" width="170">
            </div>
           </div>
            <!-- End Logo Footer-->

            <!-- Social Icons-->
            <ul class="social">
                <li>
                    <div>
                        <a href="#" class="facebook">
                            <i class="fa fa-facebook"></i>
                        </a>
                    </div>
                </li>
                <li>
                    <div>
                        <a href="#" class="twitter-icon">
                            <i class="fa fa-twitter"></i>
                        </a>
                    </div>
                </li>
                <li>
                    <div>
                        <a href="#" class="vimeo">
                            <i class="fa fa-vimeo-square"></i>
                        </a>
                    </div>
                </li>
                <li>
                    <div>
                        <a href="#" class="google-plus">
                            <i class="fa fa-google-plus"></i>
                        </a>
                    </div>
                </li>
                <li>
                    <div>
                        <a href="#" class="youtube">
                            <i class="fa fa-youtube"></i>
                        </a>
                    </div>
                </li>
            </ul>
            <!-- End Social Icons-->
        </div>
        <!-- End Footer Top-->
        <div class="footer-down">
          <div class="container">
              <div class="row">
                  <div class="col-md-12">
                      <p>&copy; 2020 - <?php echo e(date("Y")); ?> . Зохиогчын эрхээр хамгаалагдсан. </p>
                  </div>
              </div>
          </div>
      </div>
    </footer>
    <!-- End footer-->


    </div>
    <!-- SwiperJS CDN -->
    <script src="https://unpkg.com/swiper/swiper-bundle.js"></script>
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <!-- End SwiperJS CDN -->

    <!-- Initialize swiper -->
    <script>
      var mySwiper = new Swiper('.swiper-container', {
        // Optional parameters
        direction: 'horizontal',
        loop: true,

        // If we need pagination
        pagination: {
          el: '.swiper-pagination',
        },

        // Navigation arrows
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },

        // And if we need scrollbar
        scrollbar: {
          el: '.swiper-scrollbar',
        },
      });
    </script>
    <!-- Initialize swiper end -->

    <script type="text/javascript" src="<?php echo e(url('/assets/assets/js/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/assets/assets/js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/assets/assets/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/assets/assets/js/theme-scripts.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/assets/assets/js/theme-main.js')); ?>"></script>

    <!-- End JQuert and Popup -->
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\vball.mn\resources\views/master.blade.php ENDPATH**/ ?>