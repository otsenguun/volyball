<?php $__env->startSection('content'); ?>
<div id="content" class="app-content">
    <div class="d-flex align-items-center mb-3">
        <div>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Хяналтын хуудас</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/users')); ?>">Хэрэглэгчийн жагсаалт</a></li>
                <li class="breadcrumb-item active">Хэрэглэгч нэмэх</li>
            </ul>
            <h1 class="page-header mb-0">Хэрэглэгч нэмэх</h1>
        </div>
        <div class="ml-auto">
            <a href="<?php echo e(url('/admin/users')); ?>" class="btn btn-primary"><i class="fa fa-fa-arrow-left fa-fw mr-1"></i>Буцах</a>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php if(Session('success')): ?>
                <div class="col-md-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Амжилтын мэдэгдэл:</strong> <?php echo e(Session('success')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(Session('error')): ?>
                <div class="col-md-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Алдааны мэдэгдэл:</strong> <?php echo e(Session('error')); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="card" style="padding: 25px;">
        <div class="container">
            <form action="<?php echo e(url('/admin/users/add')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <strong>Анхаар:</strong> Бид хэрэглэгчийн нууц үгийг тусгай аргаар encrypt хийдэг бөгөөд
                                буцаан decpyt хийх боломжгүй болгодог. Иймд хэрэглэгчийн анхны нууц үг бүртгэгдэж байгаа
                                утасны дугаараар тохирох болохыг анхаарна уу?
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Хэрэглэгчийн овог:</label>
                            <input type="text" name="lname" class="form-control" required="" placeholder="Last name" value="<?php if(Session('backlname')): ?><?php echo e(Session('backlname')); ?> <?php endif; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Хэрэглэгчийн нэр:</label>
                            <input type="text" name="fname" class="form-control" required="" placeholder="First name" value="<?php if(Session('backfname')): ?><?php echo e(Session('backfname')); ?> <?php endif; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Утасны дугаар:</label>
                            <input type="number" name="phone" class="form-control" required="" placeholder="+976" value="<?php if(Session('backphone')): ?><?php echo e(Session('backphone')); ?> <?php endif; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">И-Мэйл хаяг:</label>
                            <input type="email" name="email" class="form-control" required="" placeholder="example@example.com" value="<?php if(Session('backemail')): ?><?php echo e(Session('backemail')); ?> <?php endif; ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Системд нэвтэрсэн хэрэглэгч</label>
                            <input type="text" class="form-control" required="" disabled="true" value="<?php echo e(Auth::user()->email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Хэрэглэгчийн төрөл</label>
                            <select name="premission" id="" class="form-control">
                                <?php $__currentLoopData = $userPremission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $premission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($premission->id); ?>" <?php if(Session('backpremission')): ?> <?php if(Session('backpremission') == $premission->id): ?> selected="" <?php endif; ?> <?php endif; ?>><?php echo e($premission->premission); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success" type="submit">Хадгалах</button>
                            <a href="<?php echo e(url('/admin/users/add')); ?>" class="btn btn-warning">Reset хийх</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vball.mn\resources\views/admin/users/create.blade.php ENDPATH**/ ?>