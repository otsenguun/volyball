<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script type="text/javascript">


        $('.selecteddataremover').attr('hidden', true);
        $('.checkboxform').attr('hidden', true);

        $('.selectall').click(function(){

            $('.selectbox').prop('checked', $(this).prop('checked'));
            $('.selecteddataremover').attr('hidden', false);
			$('.checkboxform').attr('hidden', false);

            var total = $('.selectbox').length;
            var number = $('.selectbox:checked').length;
            if(number == 0)
            {
                $('.selecteddataremover').attr('hidden', true);
				$('.checkboxform').attr('hidden', true);
            }

        });
        $('.selectbox').change(function(){
            var total = $('.selectbox').length;
            var number = $('.selectbox:checked').length;
            if(total == number)
            {
                $('.selectall').prop('checked', true);
                $('.selecteddataremover').attr('hidden', false);
				$('.checkboxform').attr('hidden', false);
            }
            else{
                $('.selectall').prop('checked', false);
                $('.selecteddataremover').attr('hidden', false);
				$('.checkboxform').attr('hidden', false);
            }
            if(number == 0)
            {
                $('.selecteddataremover').attr('hidden', true);
				$('.checkboxform').attr('hidden', true);
            }
        });


    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customized_style'); ?>
<style type="text/css">
	.actioned-menu{
		padding-top: 20px !important;
	}
	.actioned-menu a{
		font-size: 14px;
		color: #000;
		border: 1px solid #000;
		padding: 6px;
		margin: 3px;
	}
	.actioned-menu a:hover{
		color: #fff;
		background-color: #000
	}
	.dscontent{
		color: #212837;
	    background-color: #fff;
	    border: 1px solid #c9d2e3 !important;
	    font-weight: 400;
	    text-align: center;
	    vertical-align: middle;
	    user-select: none;
	    background-color: transparent;
	    border: 1px solid transparent;
	    padding: .375rem .75rem;
	    font-size: .875rem;
	    line-height: 1.5;
	    border-radius: 6px;
	    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
	}
	.dscontent option{
		display: block;
	    width: 100%;
	    padding: 6px 20px;
	    clear: both;
	    font-weight: 400;
	    color: #212837;
	    text-align: inherit;
	    white-space: nowrap;
	    background-color: transparent;
	    border: 0;
	}
    .w-5{
        font-size: 10px !imporntant;
        width: 20px; !important;
    }
    nav .flex{
        display: none !important;
    }
	table tr th, td{
		text-align: center;
		vertical-align: middle;
	}
	.form-group label{
		border-left: 5px solid #a51c30;
		padding-left: 8px;
		margin-bottom: 10px;
	}
	table:hover{
		cursor: pointer;
	}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="content" class="app-content">
    <div class="d-flex align-items-center mb-3">
        <div>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Хяналтын хуудас</a></li>
                <li class="breadcrumb-item active">Хайлт</li>
            </ul>
            <h1 class="page-header mb-0">Түлхүүр үг: <?php echo e($searchKey); ?></h1>
            <p style="margin-top: 20px;"><?php echo e(' / Илэрц: '.$countArticle.' /'); ?></p>
        </div>
        <div class="ml-auto">
            <a href="<?php echo e(url('/admin/articles/add')); ?>" class="btn btn-primary"><i class="fa fa-plus-circle fa-fw mr-1"></i>Мэдээ нэмэх</a>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php if(Session('success')): ?>
                <div class="col-md-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Амжилтын мэдэгдэл:</strong> <?php echo e(Session('success')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(Session('error')): ?>
                <div class="col-md-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Алдааны мэдэгдэл:</strong> <?php echo e(Session('error')); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="card" style="padding: 25px;">
        <div class="tab-content p-4">
            <div class="tab-pane fade show active" id="allTab">
                <form action="<?php echo e(url('/admin/articles/search')); ?>" method="get">
                <?php echo csrf_field(); ?>
                    <div class="input-group mb-4">
                        <div class="flex-fill position-relative">
                            <div class="input-group">
                                <div class="input-group-prepend position-absolute top-0 bottom-0" style="z-index: 1020;">
                                    <span class="input-group-text bg-none border-0 pr-0"><i class="fa fa-search opacity-5"></i></span>
                                </div>
                                <input type="text" class="form-control pl-35px" name="value" placeholder="Хайлтын утга..." required=""/>
                                <submit type="hidden"></submit>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="table-responsive">
                <table class="table table-hover text-nowrap">
                    <form class="checkboxform" action="<?php echo e(url('/admin/articles/dropbox')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <thead>
                            <tr>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">
                                    <input type="checkbox" class="selectall " name="" id="">
                                </th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">№</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">Зураг</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">Нийтлэлийн гарчиг</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">Төрөл</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">Хэрэглэгч</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">Сүүлд хийгдсэн</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">#Үйл ажиллагаа</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                if(isset($_GET['page']))
                                {
                                    $cNumber = $_GET['page'] * 10 - 10;
                                }
                                else{
                                    $cNumber = 0;
                                }
                            ?>
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="width-10 align-middle">
                                    <input type="checkbox" class="selectbox" name="article_id[]" value="<?php echo e($article->id); ?>" id="">
                                </td>
                                <td class="align-middle"><?php echo e($cNumber+=1); ?></td>
                                <td class="align-middle">
                                    <img src="<?php echo e(url($article->image)); ?>" alt="Volleyball.mn" style="width: 25px;">
                                </td>
                                <td class="align-middle" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e($article->title); ?>">
                                    <?php echo e(Str::limit($article->title, 20)); ?>

                                </td>
                                <td class="align-middle">
                                    <label class="btn btn-primary"><?php echo e($article->category); ?></label>
                                </td>
                                <td class="align-middle" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e($article->useremail); ?>">
                                    <?php echo e(Str::limit($article->useremail, 12)); ?>

                                </td>
                                <td class="align-middle"><?php echo e($article->updated_at->diffForHumans()); ?></td>
                                <td class="actioned-menu">
                                    <a href="<?php echo e(url('/admin/articles/show/'.$article->id)); ?>">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(url('/admin/articles/edit/'.$article->id)); ?>">
                                        <i class="fas fa-pen-square"></i>
                                    </a>
                                    <a href="<?php echo e(url('/admin/articles/drop/'.$article->id)); ?>">
                                        <i class="fa fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($countArticle == 0): ?>
                                <tr>
                                    <td colspan="8">
                                        Хайлтын утга олдсонгүй.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfooter>
                            <tr>
                                <th class="actioned-menu" colspan="8" style="text-align: right;">
                                    <button class="btn btn-danger selecteddataremover" type="submit" disable="true">
                                        <i class="fa fa-trash-alt"></i>
                                        Идэвхижүүлснийг устга
                                    </button>
                                </th>
                            </tr>
                        </tfooter>
                    </form>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/volleyball.mn/resources/views/admin/article/search.blade.php ENDPATH**/ ?>