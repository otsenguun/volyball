<?php $__env->startSection('customized_style'); ?>
<style type="text/css">
	.usertitle{
        border-left: 3px solid #a51c30;
        padding-left: 8px;
        font-size: 16px;
        font-weight: 500;
    }
    .mt-12{
        margin-top: 12px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="content" class="app-content">
    <div class="d-flex align-items-center mb-3">
        <div>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Хяналтын хуудас</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/users')); ?>">Хэрэглэгчийн жагсаалт</a></li>
                <li class="breadcrumb-item active">Хэрэглэгчийн мэдээлэл засварлах</li>
            </ul>
            <h1 class="page-header mb-0">Хэрэглэгч: <?php echo e($user[0]->email); ?></h1>
        </div>
        <div class="ml-auto">
            <a href="<?php echo e(url('/admin/users')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left fa-fw mr-1"></i>Буцах</a>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php if(Session('success')): ?>
                <div class="col-md-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Амжилтын мэдэгдэл:</strong> <?php echo e(Session('success')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(Session('error')): ?>
                <div class="col-md-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Алдааны мэдэгдэл:</strong> <?php echo e(Session('error')); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="card" style="padding: 25px;">
        <div class="container">
            <form action="<?php echo e(url('/admin/users/edit/'.$user[0]->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <h3 class="usertitle">Хэрэглэгчийн үндсэн мэдээлэл:</h3>
                        </div>
                        <div class="form-group">
                            <label for="">Хэрэглэгчийн овог:</label>
                            <input type="text" name="lname" class="form-control" required="" value="<?php if(Session('backlname')): ?><?php echo e(Session('backlname')); ?> <?php else: ?> <?php echo e($user[0]->lname); ?> <?php endif; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Хэрэглэгчийн нэр:</label>
                            <input type="text" name="fname" class="form-control" required="" value="<?php if(Session('backfname')): ?><?php echo e(Session('backfname')); ?> <?php else: ?> <?php echo e($user[0]->fname); ?> <?php endif; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Утасны дугаар:</label>
                            <input type="text" name="phone" class="form-control" required="" value="<?php if(Session('backphone')): ?><?php echo e(Session('backphone')); ?> <?php else: ?> <?php echo e($user[0]->phone); ?> <?php endif; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">И-Мэйл хаяг:</label>
                            <input type="email" name="email" class="form-control" required="" value="<?php if(Session('backemail')): ?><?php echo e(Session('backemail')); ?> <?php else: ?> <?php echo e($user[0]->email); ?> <?php endif; ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Системд нэвтэрсэн хэрэглэгч</label>
                            <input type="text" class="form-control" required="" disabled="true" value="<?php echo e(Auth::user()->email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Хэрэглэгчийн төрөл</label>
                            <select name="premission" id="" class="form-control">
                                <?php $__currentLoopData = $userPremission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $premission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($premission->id); ?>" <?php if(Session('backpremission')): ?> <?php if(Session('backpremission') == $premission->id): ?> selected="" <?php endif; ?> <?php else: ?> <?php if($user[0]->premission == $premission->id): ?> selected="" <?php endif; ?> <?php endif; ?>><?php echo e($premission->premission); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success" type="submit">Өөрчлөлтийг хадгалах</button>
                            <a href="<?php echo e(url('/admin/users/add')); ?>" class="btn btn-warning">Reset хийх</a>
                        </div>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-md-12">
                    <hr>
                </div>
            </div>
            <form action="<?php echo e(url('/admin/users/edit/changepassword/'.$user[0]->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <h3 class="usertitle">Хэрэглэгчийн нууцлал:</h3>
                        </div>
                        <div class="form-group">
                            <div class="form-group">
                                <label for="">Нууц үг:</label>
                                <input type="password" name="password" class="form-control" required="" placeholder="Enter password">
                            </div>
                            <div class="form-group">
                                <label for="">Нууц үг давта:</label>
                                <input type="password" name="repassword" class="form-control" required="" placeholder="Enter repassword">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mt-12">
                        <div class="form-group">
                            <button class="btn btn-success" type="submit">Өөрчлөлтийг хадгалах</button>
                            <a href="<?php echo e(url('/admin/users/add')); ?>" class="btn btn-warning">Reset хийх</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vball.mn\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>