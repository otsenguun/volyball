<?php $__env->startSection('content'); ?>

    <div class="section-title" style="background:url(img/slide/1.jpg); margin-top: 40px">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h1>Бүх тоглогчид</h1>
                </div>
            </div>
        </div>
    </div>

     <!-- Section Area - Content Central -->
     <section class="content-info">

        <!-- Nav Filters -->
        <div class="portfolioFilter">
            <div class="container">
                <h5><i class="fa fa-filter" aria-hidden="true"></i>Шүүх:</h5>
                <a href="#" data-filter="*" class="current">Бүгд</a>
                <?php $__currentLoopData = $player_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#" data-filter=".<?php echo e($key); ?>"><?php echo e($item); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        <!-- End Nav Filters -->

        <div class="container padding-top">
            <div class="row portfolioContainer">

                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Item Player -->
                <div class="col-xl-3 col-lg-4 col-md-6 <?php echo e($player->player_type); ?>">
                    <div class="item-player">
                        <div class="head-player">
                            <img src="<?php echo e(asset('app/'.$player->image)); ?>" alt="location-team">
                            <div class="overlay"><a href="<?php echo e(url('show_player',$player->id)); ?>">+</a></div>
                        </div>
                        <div class="info-player">
                            <span class="number-player">
                                <?php echo e($player->huviin_number); ?>

                            </span>
                            <h4>
                                <?php echo e($player->frist_name); ?> <?php echo e($player->last_name); ?>

                                <span><?php echo e($player->player_type()); ?></span>
                            </h4>
                            <ul>
                                <li>
                                    <strong>Баг</strong> <span><img src="<?php echo e($player->getTeamLogo()); ?>" alt=""> <?php echo e($player->getTeamName()); ?> </span>
                                </li>
                                <li><strong>Тоглолтууд:</strong> <span><?php echo e($player->total_match); ?></span></li>
                                <li><strong>Нас:</strong> <span><?php echo e($player->getAge()); ?></span></li>
                            </ul>
                        </div>
                        <a href="<?php echo e(url('show_player',$player->id)); ?>" class="btn">Тоглогчыг харах <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                </div>
                <!-- End Item Player -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>
        </div>
    </section>
    <!-- End Section Area -  Content Central -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Tsenguun\voly\volleyball.mn\resources\views/players.blade.php ENDPATH**/ ?>