<?php $__env->startSection('content'); ?>
<!-- Sponsors-->
<div class="container" style="position: relative">
    <ul class="home-sponsors sponsors-carousel" style="padding: 20px 50px">
        <?php $__currentLoopData = $cooperationLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="#"><img src="<?php echo e($logo->logo); ?>" alt="<?php echo e($logo->company); ?>" /></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<!-- End Sponsors -->
<!-- section-hero-posts-->
<div class="container" style="position: relative;">
    <div class="home-slider">
      <div class="home-slider-left">
        <!-- Swiper -->
        <div class="swiper-container">
          <div class="swiper-wrapper">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key < 4): ?>
                    <div class="swiper-slide">
                    <div class="card-wrapper">
                        <article class="card" role="article">
                        <a href="<?php echo e(url('/news/'.$article->id.'/'.$article->slug)); ?>">
                            <div class="card-text">
                            <div class="card-meta"><?php echo e($article->category); ?></div>
                            <h2 class="card-title">
                                <?php echo e(Str::limit($article->title, 60)); ?>

                            </h2>
                            </div>
                            <img class="card-image" src="<?php echo e(url($article->image)); ?>" alt="<?php echo e($article->title); ?>"/>
                        </a>
                        </article>
                    </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <!-- Add Arrows -->
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
        <!-- Bottom part will go here -->
        <!-- <div class="card-container">
          <div class="card-single">
            <img src="img/blog/1.jpg" alt="" />
            <div class="card-container-text">
              <h6 class="color-white">RUGBY</h6>
              <p>Cheetahs can prove they've been the missing link</p>
            </div>
          </div>
          <div class="card-single">
            <img src="img/blog/2.jpg" alt="" />
            <div class="card-container-text">
              <h6 class="color-white">RUGBY</h6>
              <p>Cheetahs can prove they've been the missing link</p>
            </div>
          </div>
        </div> -->
        <!-- End bottom -->
      </div>
      <div class="home-slider-right">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key == 4): ?>
                <div class="card-wrapper">
                <article class="card" role="article">
                    <a href="<?php echo e(url('/news/'.$article->id.'/'.$article->slug)); ?>">
                    <div class="card-text">
                        <div class="card-meta"><?php echo e($article->category); ?></div>
                        <h2 class="card-title">
                            <?php echo e(Str::limit($article->title, 60)); ?>

                        </h2>
                    </div>
                    <img class="card-image" src="<?php echo e(url($article->image)); ?>" alt="<?php echo e($article->title); ?>"/>
                    </a>
                </article>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
</div>
<!-- End section-hero-posts-->
<!-- Section Area - Content Central -->
<section class="content-info" style="padding-top: 0px !important;">
    <?php $checkvalues = 0; ?>
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $artcile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key > 4): ?>
            <?php $checkvalues += 1; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($checkvalues == 6): ?>
        <!-- Content Central -->
        <div class="container" style="padding-top: 0px !important;">
        <div class="row">
            <!-- content Column Left -->
            <div class="col-lg-12 col-xl-12">
            <div class="col-lg-4 mb-4">
                <h3 class="clear-title no-margin">Мэдээ</h3>
            </div>
            <div class="home-slider">
                <div class="col-lg-9 col-xl-9">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key == 5): ?>
                            <div class="card-wrapper">
                                <article class="card" role="article">
                                <a href="<?php echo e(url('/news/'.$art->id.'/'.$art->slug)); ?>">
                                    <div class="card-text">
                                    <div class="card-meta"><i class="fa fa-calendar"></i> <?php echo e($art->updated_at->diffForHumans()); ?></i></div>
                                    <h2 class="card-title">
                                        <?php echo e(Str::limit($art->title, 60)); ?>

                                    </h2>
                                    </div>
                                    <img class="card-image" src="<?php echo e(url($art->image)); ?>" alt="<?php echo e($art->title); ?>"/>
                                </a>
                                </article>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-lg-3 col-xl-3">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key == 6): ?>
                            <div class="card-wrapper">
                                <article class="card" role="article">
                                <a href="<?php echo e(url('/news/'.$arti->id.'/'.$arti->slug)); ?>">
                                    <div class="card-text">
                                    <div class="card-meta"><i class="fa fa-calendar"></i> <?php echo e($arti->updated_at->diffForHumans()); ?></i></div>
                                    <h2 class="card-title">
                                        <?php echo e(Str::limit($arti->title, 60)); ?>

                                    </h2>
                                    </div>
                                    <img class="card-image" src="<?php echo e(url($arti->image)); ?>" alt="<?php echo e($arti->title); ?>"/>
                                </a>
                                </article>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="home-slider mb-4">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $artic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key > 6): ?>
                    <div class="col-lg-3 col-xl-3">
                        <div class="card-wrapper">
                            <article class="card" role="article">
                            <a href="<?php echo e(url('/news/'.$artic->id.'/'.$artic->slug)); ?>">
                                <div class="card-text">
                                <div class="card-meta"><i class="fa fa-calendar"></i> <?php echo e($artic->updated_at->diffForHumans()); ?></i></div>
                                <h2 class="card-title">
                                    <?php echo e(Str::limit($artic->title, 60)); ?>

                                </h2>
                                </div>
                                <img class="card-image" src="<?php echo e(url($artic->image)); ?>" alt="<?php echo e($artic->title); ?>"/>
                            </a>
                            </article>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <!-- End content Left -->
        </div>
        </div>
        <!-- End Content Central -->
    <?php endif; ?>

    <?php if($galleries != '[]'): ?>
    <!-- White Section -->
    <div class="white-section paddings">
      <div class="container">

          <div class="row align-items-center">
              <div class="col-lg-4">
                  <h3 class="clear-title no-margin">Спорт Галлэрэй</h3>
              </div>

              <div class="col-lg-8">
                  <!-- Nav Filters -->
                  <div class="portfolioFilter no-margin no-bg pull-right">
                      <a href="#" data-filter="*" class="current">Бүгд</a>
                      <a href="#" data-filter=".image">Зураг</a>
                  </div>
                  <!-- End Nav Filters -->
              </div>
          </div>


          <div class="row portfolioContainer margin-top">
            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- Item Gallery -->
              <div class="col-sm-6 col-lg-4 col-xl-3 image">
                  <div class="item-gallery">
                      <div class="hover small">
                          <img src="<?php echo e($gallery->image); ?>" alt="<?php echo e($gallery->title); ?>" />
                          <a class="swipebox-ligbox"  href="<?php echo e($gallery->image); ?>">
                              <div class="overlay"><i class="fa fa-plus"></i></div>
                          </a>
                      </div>
                      <div class="info-gallery">
                          <p><?php echo e($gallery->title); ?></p>
                          <i class="fa fa-picture-o"></i>
                      </div>
                  </div>
              </div>
              <!-- Item Gallery -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
    </div>
    <!-- End White Section -->
    <?php endif; ?>

</section>
<!-- End Section Area -  Content Central -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vball.mn\resources\views/index.blade.php ENDPATH**/ ?>