<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script type="text/javascript">


        $('.selecteddataremover').attr('hidden', true);
        $('.checkboxform').attr('hidden', true);

        $('.selectall').click(function(){

            $('.selectbox').prop('checked', $(this).prop('checked'));
            $('.selecteddataremover').attr('hidden', false);
			$('.checkboxform').attr('hidden', false);

            var total = $('.selectbox').length;
            var number = $('.selectbox:checked').length;
            if(number == 0)
            {
                $('.selecteddataremover').attr('hidden', true);
				$('.checkboxform').attr('hidden', true);
            }

        });
        $('.selectbox').change(function(){
            var total = $('.selectbox').length;
            var number = $('.selectbox:checked').length;
            if(total == number)
            {
                $('.selectall').prop('checked', true);
                $('.selecteddataremover').attr('hidden', false);
				$('.checkboxform').attr('hidden', false);
            }
            else{
                $('.selectall').prop('checked', false);
                $('.selecteddataremover').attr('hidden', false);
				$('.checkboxform').attr('hidden', false);
            }
            if(number == 0)
            {
                $('.selecteddataremover').attr('hidden', true);
				$('.checkboxform').attr('hidden', true);
            }
        });


    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customized_style'); ?>
<style type="text/css">
	.actioned-menu{
		padding-top: 20px !important;
	}
	.actioned-menu a{
		font-size: 14px;
		color: #000;
		border: 1px solid #000;
		padding: 6px;
		margin: 3px;
	}
	.actioned-menu a:hover{
		color: #fff;
		background-color: #000
	}
	.dscontent{
		color: #212837;
	    background-color: #fff;
	    border: 1px solid #c9d2e3 !important;
	    font-weight: 400;
	    text-align: center;
	    vertical-align: middle;
	    user-select: none;
	    background-color: transparent;
	    border: 1px solid transparent;
	    padding: .375rem .75rem;
	    font-size: .875rem;
	    line-height: 1.5;
	    border-radius: 6px;
	    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
	}
	.dscontent option{
		display: block;
	    width: 100%;
	    padding: 6px 20px;
	    clear: both;
	    font-weight: 400;
	    color: #212837;
	    text-align: inherit;
	    white-space: nowrap;
	    background-color: transparent;
	    border: 0;
	}
    .w-5{
        font-size: 10px !imporntant;
        width: 20px; !important;
    }
    nav .flex{
        display: none !important;
    }
	table tr th, td{
		text-align: center;
		vertical-align: middle;
	}
	.form-group label{
		border-left: 5px solid #a51c30;
		padding-left: 8px;
		margin-bottom: 10px;
	}
	table:hover{
		cursor: pointer;
	}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="content" class="app-content">
    <div class="d-flex align-items-center mb-3">
        <div>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Хяналтын хуудас</a></li>
                <li class="breadcrumb-item active">Хэрэглэгчийн жагсаалт</li>
            </ul>
            <h1 class="page-header mb-0">Хэрэглэгчийн жагсаалт</h1>
        </div>
        <div class="ml-auto">
            <a href="<?php echo e(url('/admin/users/add')); ?>" class="btn btn-primary"><i class="fa fa-plus-circle fa-fw mr-1"></i>Хэрэглэгч нэмэх</a>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php if(Session('success')): ?>
                <div class="col-md-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Амжилтын мэдэгдэл:</strong> <?php echo e(Session('success')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(Session('error')): ?>
                <div class="col-md-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Алдааны мэдэгдэл:</strong> <?php echo e(Session('error')); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="card" style="padding: 25px;">
        <div class="tab-content p-4">
            <div class="tab-pane fade show active" id="allTab">
                <div class="table-responsive">
                <table class="table table-hover text-nowrap">
                    <form class="checkboxform" action="<?php echo e(url('/admin/users/dropbox')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <thead>
                            <tr>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">
                                    <input type="checkbox" class="selectall " name="" id="">
                                </th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">№</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">Овог, нэр</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">Утас</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">И-Мэйл</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">Premission</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">Сүүлд хийгдсэн</th>
                                <th class="border-bottom-0 border-top-0 pt-0 pb-2">#Үйл ажиллагаа</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                if(isset($_GET['page']))
                                {
                                    $cNumber = $_GET['page'] * 10 - 10;
                                }
                                else{
                                    $cNumber = 0;
                                }
                            ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="width-10 align-middle">
                                    <input type="checkbox" class="selectbox" name="user_id[]" value="<?php echo e($user->id); ?>" id="">
                                </td>
                                <td class="align-middle"><?php echo e($cNumber+=1); ?></td>
                                <td class="align-middle">
                                    <?php echo e($user->lname.', '.$user->fname); ?>

                                </td>
                                <td class="align-middle">
                                    <?php echo e($user->phone); ?>

                                </td>
                                <td class="align-middle" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e($user->email); ?>">
                                    <?php echo e($user->email); ?>

                                </td>
                                <td class="align-middle">
                                    <label class="btn <?php if($user->premission == 1): ?> btn-success <?php else: ?> btn-warning <?php endif; ?>"><?php if($user->premission == 1): ?> Administration <?php else: ?> Admin <?php endif; ?></label>
                                </td>
                                <td class="align-middle"><?php echo e($user->updated_at->diffForHumans()); ?></td>
                                <td class="actioned-menu">
                                    <a href="<?php echo e(url('/admin/users/show/'.$user->id)); ?>">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(url('/admin/users/edit/'.$user->id)); ?>">
                                        <i class="fas fa-pen-square"></i>
                                    </a>
                                    <a href="<?php echo e(url('/admin/users/drop/'.$user->id)); ?>">
                                        <i class="fa fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($countUsers == 0): ?>
                                <tr>
                                    <td colspan="8">
                                        Одоогоор бүртгэлтэй хэрэглэгч байхгүй байна.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfooter>
                            <tr>
                                <th class="actioned-menu" colspan="8" style="text-align: right;">
                                    <button class="btn btn-danger selecteddataremover" type="submit" disable="true">
                                        <i class="fa fa-trash-alt"></i>
                                        Идэвхижүүлснийг устга
                                    </button>
                                </th>
                            </tr>
                        </tfooter>
                    </form>
                    </table>
                </div>
                <div class="d-md-flex align-items-center">
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/volleyball.mn/resources/views/admin/users/index.blade.php ENDPATH**/ ?>