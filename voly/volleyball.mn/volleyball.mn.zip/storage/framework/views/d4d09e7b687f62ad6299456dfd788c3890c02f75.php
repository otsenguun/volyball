<?php $__env->startSection('css'); ?>

    <script src="<?php echo e(url('/assets/admin/js/app.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
    <script src="<?php echo e(url('/assets/admin/plugins/jquery-migrate/dist/jquery-migrate.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>

	<link href="<?php echo e(url('/assets/admin/plugins/tag-it/css/jquery.tagit.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-slider/dist/css/bootstrap-slider.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/blueimp-file-upload/css/jquery.fileupload.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/summernote/dist/summernote.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/summernote/dist/summernote-bs4.css')); ?>" rel="stylesheet" />


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('/assets/admin/plugins/jquery-migrate/dist/jquery-migrate.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/moment/min/moment.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-slider/dist/bootstrap-slider.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-3-typeahead/bootstrap3-typeahead.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/jquery.maskedinput/src/jquery.maskedinput.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/pwstrength-bootstrap/dist/pwstrength-bootstrap.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/tag-it/js/tag-it.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/blueimp-file-upload/js/vendor/jquery.ui.widget.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/blueimp-tmpl/js/tmpl.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/summernote/dist/summernote.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="assets/admin/plugins/summernote/dist/summernote-bs4.min.js" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/highlight.js/highlight.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/js/demo/highlightjs.demo.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/js/demo/form-plugins.demo.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>

	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="content" class="app-content">
    <div class="d-flex align-items-center mb-3">
        <div>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Хяналтын хуудас</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('Competition.index')); ?>">Тэмцээний жагсаалт</a></li>
                <li class="breadcrumb-item active">Тэмцээн засах</li>
            </ul>
            <h1 class="page-header mb-0">Тэмцээн засах</h1>
        </div>
        <div class="ml-auto">
            <a href="<?php echo e(route('Competition.index')); ?>" class="btn btn-primary"><i class="fa fa-plus-circle fa-fw mr-1"></i>Буцах</a>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php if(Session('success')): ?>
                <div class="col-md-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Амжилтын мэдэгдэл:</strong> <?php echo e(Session('success')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(Session('error')): ?>
                <div class="col-md-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Алдааны мэдэгдэл:</strong> <?php echo e(Session('error')); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="card" style="padding: 25px;">
        <div class="container">
            <form action="<?php echo e(route('Competition.update',$comp->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>

                <div class="row">
                    <div class="col-md-8">
                        <h4>Үндсэн хэсэг</h4>
                        <div class="form-group">
                            <label for="">Тэмцээний гарчиг</label>
                            <input type="text" name="name"  class="form-control" required="" value="<?php echo e($comp->name); ?>">
                        </div>

                        <div class="form-group">
                            <label for=""> Тэмцээний заавар</label>
                            <textarea name="match_guide" class="summernote" id="contents" title="Contents" required="">
								<?php echo $comp->match_guide; ?>

							</textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                Эхний багийн нэр
                                <input name="main_team_name" type="text" class="form-control" value="<?php echo e($comp->main_team_name); ?>" required>
                                Эхний багийн огноо
                                <input name="score_main" type="number" class="form-control" value="<?php echo e($comp->score_main); ?>">
                                Эхний багийн холбох дугаар
                                <input name="main_team_id" type="text" class="form-control"  value="<?php echo e($comp->main_team_id); ?>">
                            </div>
                            <div class="col-md-6">
                                Дараагийн багийн нэр
                                <input name="second_team_name" type="text" class="form-control" required value="<?php echo e($comp->second_team_name); ?>">
                                Дараагийн багийн огноо
                                <input name="score_second" type="number" class="form-control" value="<?php echo e($comp->score_second); ?>">
                                Дараагийн багийн холбох дугаар
                                <input name="second_team_id" type="text" class="form-control" value="<?php echo e($comp->second_team_id); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for=""> Тэмцээний Дэлгэрэнгүй</label>
                            <textarea name="details" class="summernote" id="contents" title="Contents" required="">
								<?php if(Session('backarticle')): ?> <?php echo Session('backarticle'); ?> <?php endif; ?>

                                <?php echo $comp->details; ?>

							</textarea>
                        </div>
                        <div class="form-group">
                            <label for=""> Тэмцээний хаяг</label>
                            <textarea name="address" class="form-control">
                                <?php echo e($comp->address); ?>

							</textarea>
                        </div>
                        <hr>

                        <h4> Статистк болон MVP</h4>
                        <div class="row">
                            <div class="col-md-6">
                                Эхний багийн MVP
                                <input name="mvp_main" type="text" class="form-control" required value="<?php echo e($comp->mvp_main); ?>">
                                <?php

                                    $mvp_main_info = unserialize($comp->mvp_main_info);
                                    $mvp_second_info = unserialize($comp->mvp_second_info);
                                ?>

                                <?php $__currentLoopData = $statistic_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                Эхний <?php echo e($info); ?>

                                <input name="mvp_main_info[<?php echo e($info); ?>]" type="number" class="form-control" value="<?php echo e(isset($mvp_main_info[$info]) ? $mvp_main_info[$info] : ''); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="col-md-6">
                                Дараагийн MVP
                                <input name="mvp_second" type="text" class="form-control" required value="<?php echo e($comp->mvp_second); ?>">

                                <?php $__currentLoopData = $statistic_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                Дараагийн <?php echo e($info); ?>

                                <input name="mvp_second_info[<?php echo e($info); ?>]" type="number" class="form-control" value="<?php echo e(isset($mvp_second_info[$info]) ? $mvp_second_info[$info] : ''); ?>" >
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <h4> Сэт </h4>
                        
                        <div class="row">

                            <?php
                                $sets = unserialize($comp->sets);
                            ?>
                            <?php $__currentLoopData = $set_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                Эхний баг Сэт <?php echo e($count); ?>

                                <input name="main_set[<?php echo e($count); ?>]" type="text" class="form-control" value="<?php echo e(isset($sets['main'][$count]) ?  $sets['main'][$count] : ''); ?>">

                            </div>
                            <div class="col-md-6">
                                Дараагийн баг Сэт <?php echo e($count); ?>

                                <input name="second_set[<?php echo e($count); ?>]" type="text" class="form-control" value ="<?php echo e(isset($sets['second'][$count]) ?  $sets['second'][$count] : ''); ?>">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <h4>Тоглолтын Статистк</h4>
                            <?php

                            $match_status = unserialize($comp->match_status);

                            ?>
                        <div class="row">

                            <?php $__currentLoopData = $main_statistic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                Эхний баг <?php echo e($ms); ?>

                                <input name="request_match_status[<?php echo e($ms); ?>]" type="text" class="form-control" value="<?php echo e(isset( $match_status['main'][$ms]) ? $match_status['main'][$ms] : ''); ?>">

                            </div>
                            <div class="col-md-6">
                                Дараагийн баг <?php echo e($ms); ?>

                                <input name="request_match_second[<?php echo e($ms); ?>]" type="text" class="form-control" value="<?php echo e(isset( $match_status['second'][$ms]) ? $match_status['second'][$ms] : ''); ?>">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>


                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Хэрэглэгч</label>
                            <input type="text" class="form-control" required="" disabled="true" value="<?php echo e(Auth::user()->email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Тэмцээний төрөл</label>
                            <select name="category" id="" class="form-control">
                                    <option>-Сонго</option>
                                    <option value="1" <?php if($comp->status == 1): ?> selected <?php endif; ?>>Олон улсын</option>
                                    <option value="2" <?php if($comp->status == 2): ?> selected <?php endif; ?>>Энгийн</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Тэмцээний төлөв</label>
                            <select name="status" id="" class="form-control">
                                    <option <?php if($comp->status == 1): ?> selected <?php endif; ?> value="1">Эхлээгүй</option>
                                    <option <?php if($comp->status == 2): ?> selected <?php endif; ?> value="2">Дууссан</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="">Тэмцээний онгоо</label>
                            <input name="create_date" type="date" value="<?php echo e($comp->create_date); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="">Үзэгчид</label>
                            <input name="uzegch_count" type="number" class="form-control" value="<?php echo e($comp->uzegch_count); ?>">
                        </div>


                        <div class="form-group">
                            <label for="">Тэмцээний зураг хуулах</label>
                            <input type="file" class="form-control" name="image">
                        </div>

                        <div class="form-group">
                            <label for="">Тэмцээний backgound зураг хуулах</label>
                            <input type="file" class="form-control" name="background_image">
                        </div>

                        <div class="form-group">
                            <button class="btn btn-success" type="submit">Хадгалах</button>
                            
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Tsenguun\voly\volleyball.mn\resources\views/admin/competition/edit.blade.php ENDPATH**/ ?>