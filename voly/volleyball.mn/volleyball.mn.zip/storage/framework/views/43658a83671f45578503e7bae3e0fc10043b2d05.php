<?php $__env->startSection('css'); ?>

    <script src="<?php echo e(url('/assets/admin/js/app.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
    <script src="<?php echo e(url('/assets/admin/plugins/jquery-migrate/dist/jquery-migrate.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>

	<link href="<?php echo e(url('/assets/admin/plugins/tag-it/css/jquery.tagit.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/bootstrap-slider/dist/css/bootstrap-slider.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/blueimp-file-upload/css/jquery.fileupload.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/summernote/dist/summernote.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(url('/assets/admin/plugins/summernote/dist/summernote-bs4.css')); ?>" rel="stylesheet" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('/assets/admin/plugins/jquery-migrate/dist/jquery-migrate.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/moment/min/moment.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-slider/dist/bootstrap-slider.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/bootstrap-3-typeahead/bootstrap3-typeahead.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/jquery.maskedinput/src/jquery.maskedinput.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/pwstrength-bootstrap/dist/pwstrength-bootstrap.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/tag-it/js/tag-it.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/blueimp-file-upload/js/vendor/jquery.ui.widget.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/blueimp-tmpl/js/tmpl.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/summernote/dist/summernote.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="assets/admin/plugins/summernote/dist/summernote-bs4.min.js" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/plugins/highlight.js/highlight.min.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/js/demo/highlightjs.demo.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>
<script src="<?php echo e(url('/assets/admin/js/demo/form-plugins.demo.js')); ?>" type="9fb37375f90c006b1358e509-text/javascript"></script>

	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="content" class="app-content">
    <div class="d-flex align-items-center mb-3">
        <div>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Хяналтын хуудас</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/pictures')); ?>">Зургын сангийн жагсаалт</a></li>
                <li class="breadcrumb-item active">Зураг нэмэх</li>
            </ul>
            <h1 class="page-header mb-0">Зураг нэмэх</h1>
        </div>
        <div class="ml-auto">
            <a href="<?php echo e(url('/admin/pictures')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left fa-fw mr-1"></i>Буцах</a>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php if(Session('success')): ?>
                <div class="col-md-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Амжилтын мэдэгдэл:</strong> <?php echo e(Session('success')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(Session('error')): ?>
                <div class="col-md-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Алдааны мэдэгдэл:</strong> <?php echo e(Session('error')); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="card" style="padding: 25px;">
        <div class="container">
            <form action="<?php echo e(url('/admin/pictures/add')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label for="">Тайлбар</label>
                            <input type="text" name="title" class="form-control" required="" placeholder="Image Description" value="<?php if(Session('backtitle')): ?><?php echo e(Session('backtitle')); ?> <?php endif; ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Зураг хуулах</label>
                            <input type="file" class="form-control" name="image" required="">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success" type="submit">Хадгалах</button>
                            <a href="<?php echo e(url('/admin/pictures/add')); ?>" class="btn btn-warning">Reset хийх</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/volleyball.mn/resources/views/admin/pictures/create.blade.php ENDPATH**/ ?>